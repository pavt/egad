## TODOs

A list of TODOs for this project, PR welcome!

- [ ] Auto translate for Chinese -> English / English -> Chinese. With a checkbox to opt-in in the new challenge issues.

- [ ] Local playground generator for devs

- [ ] A plugin for TypeScript Playground that provides some hint and form functionality to boost the experiences on taking challenges

- [ ] More learning resources

- [ ] "Recent Challenges" section in the README

