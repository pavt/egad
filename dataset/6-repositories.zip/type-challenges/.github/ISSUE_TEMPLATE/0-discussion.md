---
name: Discussion
about: General discussions.
title: ""
labels: discussion
---

<!--

💭 Discussion

Talk anything about TypeScript or its Type System.

-->
