# Text Input

<img width="800" src="./textinput.gif" />
