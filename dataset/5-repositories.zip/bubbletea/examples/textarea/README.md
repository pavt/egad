# Text Area

<img width="800" src="./textarea.gif" />
