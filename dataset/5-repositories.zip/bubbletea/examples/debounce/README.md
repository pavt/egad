# Debounce

<img width="800" src="./debounce.gif" />
