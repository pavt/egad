# Stopwatch

<img width="800" src="./stopwatch.gif" />
