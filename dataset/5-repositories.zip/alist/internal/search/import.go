package search

import (
	_ "github.com/alist-org/alist/v3/internal/search/bleve"
	_ "github.com/alist-org/alist/v3/internal/search/db"
)
