package op

var WORK = "work"
